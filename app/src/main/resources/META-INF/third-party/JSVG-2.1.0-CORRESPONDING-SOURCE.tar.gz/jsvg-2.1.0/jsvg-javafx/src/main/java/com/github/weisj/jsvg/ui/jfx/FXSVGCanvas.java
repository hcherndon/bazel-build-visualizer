/*
 * MIT License
 *
 * Copyright (c) 2025-2026 Jannis Weis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
 * associated documentation files (the "Software"), to deal in the Software without restriction,
 * including without limitation the rights to use, copy, modify, merge, publish, distribute,
 * sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or
 * substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
 * NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 */
package com.github.weisj.jsvg.ui.jfx;

import static javafx.animation.Animation.INDEFINITE;

import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.beans.InvalidationListener;
import javafx.beans.property.*;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Control;
import javafx.scene.control.Skin;
import javafx.scene.control.SkinBase;
import javafx.util.Duration;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import com.github.weisj.jsvg.SVGDocument;
import com.github.weisj.jsvg.animation.AnimationPeriod;
import com.github.weisj.jsvg.renderer.animation.Animation;
import com.github.weisj.jsvg.ui.jfx.skin.FXSVGCanvasSkin;
import com.github.weisj.jsvg.view.ViewBox;

/**
 * A JavaFX node for displaying a {@link SVGDocument}}
 */
public final class FXSVGCanvas extends Control {

    public enum RenderBackend {
        /**
         * Renders directly to a {@link GraphicsContext} and benefits from some hardware acceleration.
         * The majority of SVG's will render correctly, but some specific features e.g. Filters, Masks may not
         */
        JavaFX,
        /**
         * Renders using JSVG AWT implementation, which may be slower to update but may display the SVG more accurately
         */
        AWT
    }

    private static final String STYLE_CLASS = "fx-svg-canvas";
    private static final String STYLE_CLASS_TRANSPARENT_PATTERN = "show-transparent-pattern";
    private static final RenderBackend DEFAULT_RENDER_BACKEND = RenderBackend.JavaFX;
    private static final ViewBox DEFAULT_VIEW_BOX = null;
    private static final AnimationPeriod DEFAULT_ANIMATION = new AnimationPeriod(0, 0, false);
    private static final boolean DEFAULT_ANIMATED = true;
    private static final boolean DEFAULT_SHOW_TRANSPARENT_PATTERN = false;

    private final Timeline timeline = new Timeline();
    private final LongProperty elapsedAnimationTime = new SimpleLongProperty();

    public FXSVGCanvas() {
        getStyleClass().add(STYLE_CLASS);
        if (getShowTransparentPattern()) getStyleClass().add(STYLE_CLASS_TRANSPARENT_PATTERN);

        InvalidationListener animationModificationListener = observable -> setupAnimation();
        animated.addListener(animationModificationListener);
        document.addListener(animationModificationListener);

        showTransparentPatternProperty().addListener((observable, oldValue, newValue) -> {
            if (oldValue) getStyleClass().remove(STYLE_CLASS_TRANSPARENT_PATTERN);
            if (newValue) getStyleClass().add(STYLE_CLASS_TRANSPARENT_PATTERN);
        });

    }

    private Animation currentAnimation() {
        if (!isAnimated()) {
            return DEFAULT_ANIMATION;
        }
        SVGDocument currentDocument = getDocument();
        if (currentDocument != null) {
            return currentDocument.animation();
        }
        return DEFAULT_ANIMATION;
    }

    private void setupAnimation() {
        Animation animation = currentAnimation();

        timeline.getKeyFrames().clear();
        if (animation.duration() <= 0) {
            timeline.stop();
            return;
        }
        timeline.getKeyFrames()
                .add(new KeyFrame(Duration.millis(animation.startTime()), new KeyValue(elapsedAnimationTime, 0)));
        timeline.getKeyFrames().add(new KeyFrame(Duration.millis(animation.endTime()),
                new KeyValue(elapsedAnimationTime, animation.endTime())));
        timeline.setCycleCount(INDEFINITE);
        timeline.playFromStart();
    }

    ////////////////////////////////////////////////

    /**
     * Requests that the SVG Document be repainted
     * In most cases this is not necessary, as the canvas will automatically be repainted when any properties (e.g. document, view-box, backend) are changed
     */
    public void repaint() {
        SkinBase<?> skin = (SkinBase<?>) getSkin();
        if (skin != null) {
            FXSVGCanvasSkin fxSkin = (FXSVGCanvasSkin) skin;
            fxSkin.markDirty();
        }
    }

    public void playAnimation() {
        timeline.play();
    }

    public void pauseAnimation() {
        timeline.pause();
    }

    public void restartAnimation() {
        timeline.playFromStart();
    }

    public void stopAnimation() {
        timeline.stop();
    }

    public boolean isAnimationPlaying() {
        return timeline.getStatus() == javafx.animation.Animation.Status.RUNNING;
    }

    ////////////////////////////////////////////////

    private final ObjectProperty<@NotNull RenderBackend> renderBackend =
            new SimpleObjectProperty<>(DEFAULT_RENDER_BACKEND);

    public @NotNull RenderBackend getRenderBackend() {
        return renderBackend.get();
    }

    public @NotNull ObjectProperty<@NotNull RenderBackend> renderBackendProperty() {
        return renderBackend;
    }

    public void setRenderBackend(@NotNull RenderBackend renderer) {
        this.renderBackend.set(renderer);
    }

    ////////////////////////////////////////////////

    private final ObjectProperty<@Nullable SVGDocument> document = new SimpleObjectProperty<>();

    public @Nullable SVGDocument getDocument() {
        return document.get();
    }

    public @NotNull ObjectProperty<@Nullable SVGDocument> documentProperty() {
        return document;
    }

    public void setDocument(@Nullable SVGDocument document) {
        this.document.set(document);
    }

    ////////////////////////////////////////////////

    private final ObjectProperty<@Nullable ViewBox> viewBox = new SimpleObjectProperty<>(DEFAULT_VIEW_BOX);

    public @Nullable ViewBox getViewBox() {
        return viewBox.get();
    }

    public @NotNull ObjectProperty<@Nullable ViewBox> viewBoxProperty() {
        return viewBox;
    }

    public void setViewBox(@Nullable ViewBox viewBox) {
        this.viewBox.set(viewBox);
    }

    ////////////////////////////////////////////////

    private final BooleanProperty animated = new SimpleBooleanProperty(DEFAULT_ANIMATED);

    public boolean isAnimated() {
        return animated.get();
    }

    public @NotNull BooleanProperty animatedProperty() {
        return animated;
    }

    public void setAnimated(boolean animated) {
        this.animated.set(animated);
    }

    ////////////////////////////////////////////////

    private final BooleanProperty showTransparentPattern = new SimpleBooleanProperty(DEFAULT_SHOW_TRANSPARENT_PATTERN);

    public boolean getShowTransparentPattern() {
        return showTransparentPattern.get();
    }

    public BooleanProperty showTransparentPatternProperty() {
        return showTransparentPattern;
    }

    public void setShowTransparentPattern(boolean showTransparentPattern) {
        this.showTransparentPattern.set(showTransparentPattern);
    }

    ////////////////////////////////////////////////

    @Override
    public String getUserAgentStylesheet() {
        return FXSVGCanvas.class.getResource("fx-svg-canvas.css").toExternalForm();
    }

    @Override
    protected Skin<?> createDefaultSkin() {
        return new FXSVGCanvasSkin(this, elapsedAnimationTime);
    }
}
